# Developer surveys page: copy

All copy on the page, in order. Interactive parts are marked; their sample data lives in the page script.

## Hero

**H1:** Developer surveys on what AI changed
AI changed how your teams build software. Your delivery metrics show what they shipped, and LinearB Surveys shows whether the people who shipped it are holding up and bought in, team by team.
- Link: Book a demo
- Link: Start free trial

## Hero demo: survey results (interactive)

**H2:** Q4 developer survey

## Logo strip

Existing logo carousel component. No changes.

## Topics (interactive respondent view)

**H2:** Ask questions only an engineer can answer
AI only pays off if your developers trust it. Ask them with topics written for engineers, and read the comments behind the scores.
- AI-assisted development
- Productivity and workflow
- Code quality and maintainability
- Developer experience
- Satisfaction and well-being
- + Write your own topic
See what’s new in LinearB Surveys →
- Button: AI-assisted development
- Button: Code quality
- Button: Productivity and workflow
- Button: Your own topic

## Results lens (interactive)

**H2:** See whether a problem belongs to one team or every team
LinearB scores every team against every topic you asked about, so the same results answer two different questions.
- Button: Read a row
- Button: Read a column
**H3:** Q3 developer survey

## Trust

**H2:** Anonymous enough for honest answers
**H3:** Anonymous by design
LinearB hides any score with fewer than 3 responses and any comment with fewer than 5, so a small team can still answer openly.
**H3:** Results by team, not by person
Results roll up by team and topic, and small groups show N/A, so no one can be picked out.
**H3:** Results stay with admins
Only Primary Admins and Super Users can create surveys and see results, and you choose who receives each survey.
**H3:** Natively secure, obsessively compliant
Independently audited, with evidence of our controls available on request. LinearB participates in the EU-U.S. Data Privacy Framework.

## Act: annotated timeline

**H2:** Act on what the survey surfaces
Survey results sit in the same platform as the delivery metrics for the same teams, so you can go from what a team said to a change in workflow automation or AI code reviews , and then check whether it helped.
**H3:** Mobile · AI-assisted development
“Reviewing AI-written PRs takes longer than writing the code.”
“Big PRs sit for days before anyone picks them up.”
- Additional review for large PRs
- Estimated time to review on every PR
- AI code review
2.6 → 3.4
Same topic, same team, eight weeks later
“Large PRs get a second reviewer the same day now.”

## Cross-link to engineering metrics

**H2:** See what your teams shipped beside what they said
LinearB engineering metrics track cycle time, DORA and AI adoption for the same teams you survey, in the same platform.
- Link: See engineering metrics

## FAQ

**H2:** Developer surveys FAQs
**Q:** We already run an engagement survey. Why another one?
Company engagement surveys cover everyone from sales to legal, use questions you didn’t write, and report by department weeks later. LinearB Surveys asks questions only engineers can answer, scores them by delivery team, in the same platform as the delivery metrics for those teams.
**Q:** Are responses anonymous?
Yes. LinearB hides scores for any team, topic or question with fewer than 3 responses, and hides comments, open-text answers and multiple-choice selections with fewer than 5.
**Q:** Who can see the results?
Primary Admins and Super Users. They create, launch and end surveys and view results. Team managers and other users don’t see survey results.
**Q:** How do developers receive the survey?
Through a Slack direct message with a personal link, so they can answer without logging in to LinearB. Organizations without Slack can contact LinearB support about enabling Surveys. Read the Surveys docs →
**Q:** Can I write my own questions?
Yes. Add your own topics and questions alongside the standard ones, as 1 to 5 ratings, multiple choice or open text. Ratings feed the scores. Multiple-choice answers show as their own results, and open-text answers come out in the CSV export.
**Q:** How often should we run a survey?
We recommend an organization-wide survey each quarter, with pulse surveys for single teams in between. Duplicate a survey to run it again, so each round compares like with like.

## Closing CTA

**H2:** Ask your developers how the last year of AI landed
- Link: Book a demo
- Link: Start free trial
