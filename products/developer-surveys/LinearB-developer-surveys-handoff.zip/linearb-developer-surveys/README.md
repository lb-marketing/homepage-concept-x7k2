# Developer surveys page handoff

Hi Mike. This is the new Developer surveys product page, which replaces `/platform/developer-surveys`. It's the same build as the MCP server and engineering metrics pages: one static reference page plus the copy. The nav, footer and the review panel (variants) are stripped out, so use the site's own.

## What's in here

| File | What it is |
| :-- | :-- |
| `reference-page/index.html` | **Start here.** The whole page as designed, from the hero to the closing CTA, as one static HTML file. Open it in a browser (it needs a connection for fonts). Use it for layout, spacing, section order and how the demos behave. It's not production code. |
| `page-copy.md` | All the copy in page order, with the interactive sections marked. |

## Sections, and what Studio already covers

| Section | Build it with |
| :-- | :-- |
| Hero (heading, subheading, two CTAs) | Studio |
| Hero demo: survey results heatmap and drill-down | **Code component.** Click any score to see that team's questions, the 1 to 5 answer spread and comments. Comments hide below 5 responses and scores below 3, matching the product. |
| Logo strip | Existing carousel |
| Topics: copy and topic chips on the left, respondent view on the right | Copy in Studio. The respondent view is a **code component** (a four-way picker that swaps the question). |
| Slack (dark band): copy and ticks left, Slack DM mock right | Copy in Studio. The Slack mock is static HTML, so it can be an image or a small code component. |
| Results lens: one heatmap, "Read a row" or "Read a column" | **Code component** (a two-way toggle that highlights a row or a column). |
| Trust: three icon cards and the security bar | Studio (same block as the MCP page's trust section) |
| Act: annotated timeline (what the team said, what changed, the pulse result, plus the score line) | Static. Studio cards plus a small chart, or one code component. |
| Cross-link to engineering metrics | Existing cross-link band |
| FAQ | Existing accordion |
| Closing CTA | Existing product page close |

## Good to know

- **No layout shift.** The heatmap drill-down, the respondent form and the lens caption all have fixed heights, so clicking never moves the page. Please keep that in the components.
- **Responsive:** checked at 1280, 1100 and 375px, with no sideways scrolling. Below 560px the heatmap column headers switch to short labels (`xs` in the script) and the toggle buttons get bigger tap targets.
- **Assets:** the Slack logo, the LinearB mark and the trust icons are all inlined SVG, so nothing needs uploading. Two trust icons come from the brand icon set (User-Multiple-Group, User-Setting-Gear). The "anonymous" eye-with-a-slash is hand-drawn, because the set has no lock or eye-off icon.
- **Colours:** everything uses brand variables except the green "Start survey" button in the Slack mock, which is Slack's own button colour.
- **Sample data:** every number, team, person and comment in the demos is sample data, and each demo says so. The question text for the standard topics is the product's real wording.
- **Links to map:** "See engineering metrics" points at `../engineering-metrics/`, so swap it for the live URL. "Start free trial" is a placeholder (`#top`). "Book a demo", the docs, the blog, workflow automation and AI code reviews already point at live linearb.io URLs.
- **Search:** the page has one H1, and every adjacent block of text is separated in the markup, so text never runs together when it's crawled or copied.

## Open items, not blocking the build

- **Targeting "named people":** the published Surveys blog says you can send to named individuals. The help article only mentions teams and groups. Product to confirm before launch.
- **"+ 5 more" topics** assumes ten standard topics, which comes from the launch brief. The docs don't give a count.

Questions about the copy or design go to Jamie.
